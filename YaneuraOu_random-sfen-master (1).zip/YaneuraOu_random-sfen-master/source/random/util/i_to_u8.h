﻿#ifndef _ITOU8_H_
#define _ITOU8_H_

#include <string>

// 数字から文字列の関数が多発するのでここにまとめとく
std::string i_to_u8(int i);

#endif _ITOU8_H_
